import axios from "axios"
import { useEffect, useState } from "react"
import './showCharacters.css'
import CardCharacter from "./CardCharacter"


const url = "http://localhost:8080/characters"
const ShowCharacters = () => {

  const [state, setState] = useState({ characters: [], cards: [] })
  const formateCard = () => {
    console.log(state.characters)
    return state.characters.map((character) => 
       {<CardCharacter img = {character.img} name ={character.name}  description = {character.description} />}
       ); 
       /* setState({ ...state, cards: cards }) */
    
  };
  useEffect(() => {
    getAllCharacters()
    console.log(state.characters)
    setState({ ...state, cards: formateCard() })
  }, [console.log(state.characters)])
  const getAllCharacters = async () => {
    const response = await axios.get(url)
    let data = response.data;
    setState({ ...state, characters: data });
    console.log(data)


  }


  // create, read, update, delete 
  const handleEditCharacter = (characterId) => {
    // Lógica para redirigir a la página de edición con el ID del personaje
    navigate(`/edit/${characterId}`)
  };

  const handleDeleteCharacter = (characterId) => {
    // Lógica para redirigir a la página de eliminación con el ID del personaje
    navigate(`/delete/${characterId}`);
  };

  return (
    <>
      <div className="box">
        {state.cards}
      </div>
    </>
  )


}

export default ShowCharacters