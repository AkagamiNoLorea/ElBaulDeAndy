

const CardCharacter = (character) => {
    return (
        <>
        <div className="contenedor-img">
            <img src ={character.img} alt="" className="img"/> 
            <div className="contenedor-datos">
                <h3>{character.name}</h3>
                <p>{character.description}</p>
            </div>
            {/* <link to ="/edit "><button onClick={() => handleEditCharacter(character.id)}>Editar</button></link>
            <link to ="/delete "><button onClick={() => handleDeleteCharacter(character.id)}>Eliminar</button></link> */}
        </div>
        </>
    )
}

export default CardCharacter